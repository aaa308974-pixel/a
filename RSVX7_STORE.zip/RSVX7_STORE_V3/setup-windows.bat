@echo off
setlocal
cd /d "%~dp0"
echo Building production source from the two local Vendure project folders...
py -3 install.py --backend "%USERPROFILE%\Desktop\RSVX7_Vendure_Kit\rsvx7-backend" --storefront "%USERPROFILE%\Desktop\RSVX7_Vendure_Kit\rsvx7-vendure-storefront" --output "%~dp0RSVX7_STORE_PRODUCTION"
if errorlevel 1 (
  echo Installation failed. Check folder paths and error above.
  pause
  exit /b 1
)
echo Done. Edit RSVX7_STORE_PRODUCTION\.env.example and save as .env on VPS.
echo Copy RSVX7_STORE_PRODUCTION folder to your VPS and run bash start.sh.
pause
