# RSVX7 STORE v3 — Evidence and security boundaries

## Executed in this build environment

- PASS: 3 Python `unittest` tests (`tests/test_installer.py`) for assembling source from fixture Vendure / Next.js layouts, Arabic locale removal, dashboard auth / private file configuration, and anti-overwrite behavior.
- PASS: 14 TypeScript / TSX files parsed with TypeScript syntax parser (parse only; no TypeScript typecheck or package resolution).
- PASS: `python -m py_compile install.py`.
- PASS: `bash -n deploy/start.sh`.
- PASS: `yaml.safe_load(deploy/docker-compose.yml)` and five services recognized.
- PASS: archive format and checksum confirmed for the ZIP generated from this folder.

## NOT executed / NOT verified

- Vendure/NestJS/Next.js production `npm run build` (official upstream dependencies unavailable locally).
- PostgreSQL initialization / migrations / Docker deployment.
- Payment flow, currency configuration, cart, checkout, order settlement, refund/cancellation reconciliation.
- Dashboard GraphQL extension runtime functionality, including ZIP upload.
- Access control tests on actual running endpoints, concurrency tests, authorization bypass tests, malware checks inside uploaded archives.
- TLS/DNS/domain provisioning and SMTP / password reset.

## Release blockers

1. Complete integration tests of add-funds, concurrent debit, replayed payment, chargebacks/cancellations/refunds, zero-balance accounts and unauthorized topups.
2. Verify file upload in live Vendure Dashboard and ownership checks for each download. 12 MiB max per archive; not suitable for larger products until private streaming storage is implemented.
3. Configure USD channel and correct store policies, verify email reset transport, audit all dependencies, add monitoring, validate encrypted database/file backups and restore.
4. Implement and test **atomic** refund ledger reconciliation and digital-product-specific checkout (existing starter expects shipping/address). **Do not accept real paid purchases until these are addressed.**

No independent penetration test has been performed. There can be unknown vulnerabilities.
