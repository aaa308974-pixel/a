#!/usr/bin/env python3
"""Compose RSVX7 STORE v3 from official Vendure 3.8 scaffold + Next.js starter.
Copies source, does not touch or copy databases, uploaded files, or .env secrets.
Safe to re-run into a fresh output directory. Requires Python >=3.10.
"""
import argparse
import json
import re
import shutil
from pathlib import Path

KIT = Path(__file__).resolve().parent


def read(path): return path.read_text(encoding='utf8')
def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value, encoding='utf8')

def check(root, marker):
    if not (root/marker).exists():
        raise SystemExit(f'Missing {marker} in {root}. Supply your existing official project directory.')

def copy_source(src, target):
    shutil.copytree(src, target, dirs_exist_ok=True, ignore=shutil.ignore_patterns(
        'node_modules', '.git', '.next', 'dist', 'build', '.env', '.env.*', 'database.sqlite',
        'sqlite.db', '*.sqlite', '*.sqlite3', 'private-files', 'static/assets', 'assets', '__pycache__',
        '*.log', '.turbo', '*.before-rsvx7-v2', '*.before-rsvx7'))

def backend(target):
    source=target/'src/vendure-config.ts'
    check(target, 'src/vendure-config.ts')
    dst=target/'src/plugins/rsvx7-store'
    shutil.copytree(KIT/'plugins/rsvx7-store', dst, dirs_exist_ok=True)
    code=read(source)
    # Remove original v2 plugin so entities and wallet resolvers are not registered twice.
    code=re.sub(r"^import\s*\{\s*Rsvx7WalletPlugin\s*\}\s*from\s*['\"][^'\"]+['\"];?\s*\n", '', code, flags=re.M)
    code=re.sub(r'\bRsvx7WalletPlugin\s*,?', '', code)
    code=code.replace("'https://www.my-shop.com/assets/'", "(process.env.SITE_URL || 'http://localhost:3001') + '/assets/'")
    code=re.sub(r"^import\s*\{\s*Rsvx7StorePlugin\s*\}.*\n",'',code,flags=re.M)
    marker='// RSVX7-V3-PRODUCTION-SETTINGS'
    if marker in code: code=code.split(marker)[0].rstrip()+"\n"
    code="import { Rsvx7StorePlugin } from './plugins/rsvx7-store/store.plugin';\nimport { json as rsvx7Json } from 'express';\n"+code
    # Config object has mutable options after definition; avoid brittle parsing of scaffold internals.
    code += '''\n// RSVX7-V3-PRODUCTION-SETTINGS
// Environment-file-only configuration; no secrets in the repository.
const live = process.env.NODE_ENV === 'production' && process.env.RSVX7_RUNTIME === '1';
if (live && (!process.env.COOKIE_SECRET || !process.env.SUPERADMIN_PASSWORD ||
             process.env.SUPERADMIN_PASSWORD === 'superadmin')) {
  throw new Error('Set strong COOKIE_SECRET and SUPERADMIN_PASSWORD before launching production.');
}
config.authOptions = {
  ...config.authOptions,
  tokenMethod: ['cookie', 'bearer'],
  cookieOptions: {...config.authOptions.cookieOptions,
    secret: process.env.COOKIE_SECRET || 'local-testing-change-this-secret',
    sameSite: 'lax', secure: live, httpOnly: true },
  superadminCredentials: {
    identifier: process.env.SUPERADMIN_USERNAME || 'superadmin',
    password: process.env.SUPERADMIN_PASSWORD || 'superadmin',
  },
  requireVerification: false,
};
config.apiOptions = {
  ...config.apiOptions,
  port: 3000,
  hostname: '0.0.0.0',
  cors: {origin: (process.env.SITE_URL || 'http://localhost:3001'), credentials:true},
  csrfPrevention: live,
  introspection: !live,
  adminApiPlayground: !live,
  shopApiPlayground: !live,
  middleware: [...(config.apiOptions.middleware || []),
    {handler: rsvx7Json({limit:'17mb'}), route:'/admin-api', beforeListen:true}],
};
if (process.env.DB_HOST) {
  config.dbConnectionOptions = {
    type: 'postgres', host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT || 5432),
    username: process.env.DB_USERNAME, password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME || 'rsvx7',
    synchronize: process.env.DB_BOOTSTRAP === '1',
    logging: false,
  };
}
config.plugins = [...(config.plugins || []), Rsvx7StorePlugin];
'''
    write(source,code)
    package=target/'package.json'
    data=json.loads(read(package))
    # Vendure generated scaffold includes graphql, express and native DB drivers;
    # use direct deps for plugin-resolver imports and PostgreSQL only.
    deps=data.setdefault('dependencies',{})
    deps.setdefault('@nestjs/common','^11.1.0')
    deps.setdefault('@nestjs/graphql','^13.2.0')
    deps.setdefault('typeorm','^0.3.25')
    deps.setdefault('@vendure/dashboard','3.8.0')
    deps.setdefault('pg','^8.14.1')
    deps.setdefault('graphql-tag','^2.12.6')
    deps.setdefault('express','^5.1.0')
    write(package,json.dumps(data,indent=2)+'\n')
    shutil.copy2(KIT/'plugins/initialize-empty.ts', target/'src/initialize-empty.ts')
    old=target/'src/plugins/rsvx7-wallet'
    if old.exists(): shutil.rmtree(old)
    # A separate node process worker must use the same config / plugin.

def storefront(target):
    check(target,'src/site/home/hero-section.tsx')
    src=target/'src'
    routing=src/'platform/i18n/routing.ts'
    write(routing,'''import {defineRouting} from 'next-intl/routing';
export const routing = defineRouting({locales:['en'], defaultLocale:'en'});
export type Locale = (typeof routing.locales)[number];
export const localeNames: Record<Locale,string> = {en:'English'};
''')
    write(src/'platform/i18n/locale-utils.ts', '''import type {Locale} from './routing';
export function toOgLocale(_locale: string): string {return 'en_US';}
export function toIntlLocale(_locale: string): string {return 'en-US';}
''')
    msgs=src/'site/i18n/messages.ts'
    text=read(msgs)
    # v1 introduced a temporary Arabic import which must not remain.
    text=text.replace("loaders[locale] ?? (locale === 'ar' ? loaders.en : undefined)", 'loaders[locale]')
    text=re.sub(r"\n\s*if \(locale === 'ar'\) \{[\s\S]*?\n\s*\}\n(?=\s*return messages;)", '\n', text)
    write(msgs,text)
    (src/'site/i18n/ar.json').unlink(missing_ok=True)
    layout=src/'site/locale-layout.tsx'
    v=read(layout).replace("dir={locale === 'ar' ? 'rtl' : 'ltr'}",'dir="ltr"')
    v=v.replace('<html lang={locale} data-scroll-behavior=', '<html lang={locale} dir="ltr" data-scroll-behavior=')
    write(layout,v)
    shutil.copy2(KIT/'storefront/hero-section.tsx',src/'site/home/hero-section.tsx')
    shutil.copy2(KIT/'storefront/footer.tsx',src/'site/footer.tsx')
    css=src/'app/[locale]/globals.css'
    t=read(css); marker='/* RSVX7 STORE branded dark/red theme.'
    if marker in t: t=t.split(marker)[0].rstrip()+'\n'
    write(css,t+'\n'+read(KIT/'storefront/theme.css'))
    nav=src/'site/navigation/navbar.tsx'; text=read(nav)
    text=text.replace('<Image src="/vendure.svg" alt="Vendure" width={40} height={27} className="h-6 w-auto dark:invert" />',
      '<span className="flex items-center gap-2 rsvx7-brand"><span className="rsvx7-brand-mark">R7</span><span>RSVX7 <em>STORE</em></span></span>')
    if '<Image' not in text: text=text.replace('import Image from "next/image";\n','')
    text=text.replace("import {LanguagePicker} from '@/site/navigation/navbar/language-picker';\n",'')
    text=re.sub(r'\s*<Suspense>\s*<LanguagePicker\s*/>\s*</Suspense>', '', text)
    # v2 wallet link may exist: retain one wallet link plus add Downloads.
    if 'href="/wallet"' not in text:
        text=text.replace('<nav className="hidden md:flex items-center gap-6">', '<nav className="hidden md:flex items-center gap-6"><NavigationLink href="/wallet">USD Wallet</NavigationLink>')
    if 'href="/downloads"' not in text:
        text=text.replace('<nav className="hidden md:flex items-center gap-6">', '<nav className="hidden md:flex items-center gap-6"><NavigationLink href="/downloads">My Downloads</NavigationLink>')
    write(nav,text)
    provider=src/'site/providers/theme-provider.tsx'
    text=read(provider).replace('defaultTheme="system"','defaultTheme="dark"').replace('enableSystem','forcedTheme="dark"')
    write(provider,text)
    write(src/'site/wallet/page.tsx',read(KIT/'storefront/wallet.tsx'))
    write(src/'app/[locale]/wallet/page.tsx',read(KIT/'storefront/wallet-route.tsx'))
    write(src/'site/downloads/page.tsx',read(KIT/'storefront/downloads.tsx'))
    write(src/'app/[locale]/downloads/page.tsx',read(KIT/'storefront/downloads-route.tsx'))
    write(src/'app/api/rsvx7-download/route.ts',read(KIT/'storefront/download-route.ts'))
    # Route dynamic personalized lookups under suspense; explicit instant=false fixes Next 16.3.
    reg=src/'features/authentication/routes/register/actions.ts'
    text=read(reg).replace('`/verify-pending?redirectTo=${encodeURIComponent(redirectTo)}`', '`/sign-in?registered=1&redirectTo=${encodeURIComponent(redirectTo)}`').replace("'/verify-pending'", "'/sign-in?registered=1'")
    write(reg,text)
    pkg=target/'package.json';data=json.loads(read(pkg));data['name']='rsvx7-storefront';write(pkg,json.dumps(data,indent=2)+'\n')
    # Brand metadata no secrets.
    en=src/'site/home/messages/en.json'
    obj=json.loads(read(en));obj['Home']['pageTitle']='Cybersecurity Tools & Digital Downloads'
    obj['Home']['description']='Secure digital storefront for authorized cybersecurity training and software.'
    obj['Home']['ogDescription']=obj['Home']['description']
    write(en,json.dumps(obj,indent=2)+'\n')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--backend',type=Path,required=True)
    ap.add_argument('--storefront',type=Path,required=True)
    ap.add_argument('--output',type=Path,default=Path('production'))
    args=ap.parse_args()
    backend_src=args.backend.resolve(); storefront_src=args.storefront.resolve(); out=args.output.resolve()
    check(backend_src,'src/vendure-config.ts');check(storefront_src,'src/site/home/hero-section.tsx')
    if out==backend_src or out==storefront_src or out in backend_src.parents or out in storefront_src.parents:
        raise SystemExit('Output must be separate from source project directories')
    if out.exists() and any(out.iterdir()): raise SystemExit('Output must be a new empty directory to avoid destroying existing data')
    (out/'backend').mkdir(parents=True,exist_ok=True)
    (out/'storefront').mkdir(parents=True,exist_ok=True)
    copy_source(backend_src,out/'backend');copy_source(storefront_src,out/'storefront')
    backend(out/'backend');storefront(out/'storefront')
    for name in ['docker-compose.yml','Caddyfile','Dockerfile.backend','Dockerfile.storefront','.env.example','start.sh','verify.sh']:
        shutil.copy2(KIT/'deploy'/name,out/name)
    print('Prepared production source (database remains untouched):',out)
    print('NEXT: Copy .env.example to .env, set domain, passwords, then run bash start.sh on VPS')

if __name__=='__main__':main()
