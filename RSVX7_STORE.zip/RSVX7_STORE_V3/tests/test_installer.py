import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('rsvx7_installer',ROOT/'install.py')
install=importlib.util.module_from_spec(spec)
spec.loader.exec_module(install)

class PackageTests(unittest.TestCase):
  def test_sources_and_permissions(self):
    plugin=(ROOT/'plugins/rsvx7-store/store.plugin.ts').read_text()
    digital=(ROOT/'plugins/rsvx7-store/digital.service.ts').read_text()
    wallet=(ROOT/'plugins/rsvx7-store/wallet.service.ts').read_text()
    self.assertIn('@Allow(Permission.SuperAdmin) @Mutation()',plugin)
    self.assertNotIn('@Allow(Permission.Public) @Mutation()',plugin)
    self.assertIn('LOGIN_REQUIRED',wallet)
    self.assertIn('ORDER_NOT_OWNED',wallet)
    self.assertIn("balanceCents >= :amount",wallet)
    self.assertIn('NO_PAID_PURCHASE',digital)
    self.assertIn('MAX_ARCHIVE_BYTES',digital)
    self.assertIn("join(PRIVATE_ROOT, row.diskName)",digital)
    self.assertNotIn('public/',digital)
  def test_install_on_fake_official_structure(self):
    with tempfile.TemporaryDirectory() as tmp:
      base=Path(tmp);back=base/'orig-back';front=base/'orig-front';out=base/'out'
      (back/'src').mkdir(parents=True)
      (front/'src/site/home/messages').mkdir(parents=True)
      (front/'src/platform/i18n').mkdir(parents=True)
      (front/'src/site/i18n').mkdir(parents=True)
      (front/'src/site/providers').mkdir(parents=True)
      (front/'src/site/navigation').mkdir(parents=True)
      (front/'src/features/authentication/routes/register').mkdir(parents=True)
      (front/'src/app/[locale]').mkdir(parents=True)
      (back/'src/vendure-config.ts').write_text("import { Rsvx7WalletPlugin } from './plugins/rsvx7-wallet/wallet.plugin';\nexport const config = { plugins: [Rsvx7WalletPlugin,] };\n")
      (back/'package.json').write_text('{"name":"backend","dependencies":{}}')
      (front/'package.json').write_text('{"name":"front"}')
      (front/'src/site/home/hero-section.tsx').write_text('placeholder')
      (front/'src/platform/i18n/routing.ts').write_text('placeholder')
      (front/'src/site/i18n/messages.ts').write_text("""const localeLoaders = loaders[locale] ?? (locale === 'ar' ? loaders.en : undefined);
if (locale === 'ar') {
  // Reuse upstream English keys as a temporary fallback for not-yet-localized screens.
  const overrides = (await import('./ar.json')).default;
  for (const [namespace, value] of Object.entries(overrides)) {
    messages[namespace] = {...(messages[namespace] as object), ...(value as object)};
  }
}
return messages;
""")
      (front/'src/site/locale-layout.tsx').write_text('<html lang={locale} data-scroll-behavior="smooth">')
      (front/'src/site/home/messages/en.json').write_text(json.dumps({'Home':{'pageTitle':'','description':'','ogDescription':''}}))
      (front/'src/app/[locale]/globals.css').write_text('body {color:red;}')
      (front/'src/site/navigation/navbar.tsx').write_text('''import Image from "next/image";
<nav className="hidden md:flex items-center gap-6"><Image src="/vendure.svg" alt="Vendure" width={40} height={27} className="h-6 w-auto dark:invert" /></nav>''')
      (front/'src/site/providers/theme-provider.tsx').write_text('defaultTheme="system" enableSystem')
      (front/'src/features/authentication/routes/register/actions.ts').write_text("'/verify-pending'")
      install.copy_source(back,out/'backend');install.copy_source(front,out/'storefront')
      install.backend(out/'backend');install.storefront(out/'storefront')
      cfg=(out/'backend/src/vendure-config.ts').read_text()
      self.assertNotIn('Rsvx7WalletPlugin',cfg)
      self.assertIn('Rsvx7StorePlugin',cfg)
      self.assertIn('csrfPrevention: live',cfg)
      self.assertIn('SuperAdmin', (out/'backend/src/plugins/rsvx7-store/store.plugin.ts').read_text())
      self.assertEqual(json.loads((out/'storefront/package.json').read_text())['name'],'rsvx7-storefront')
      self.assertIn("locales:['en']",(out/'storefront/src/platform/i18n/routing.ts').read_text())
      self.assertNotIn('ar.json',(out/'storefront/src/site/i18n/messages.ts').read_text())
      self.assertIn('instant = false',(out/'storefront/src/app/[locale]/wallet/page.tsx').read_text())
      self.assertIn('Suspense',(out/'storefront/src/site/wallet/page.tsx').read_text())
      self.assertIn('rsvx7-download',(out/'storefront/src/site/downloads/page.tsx').read_text())
  def test_deployment_is_private(self):
    yml=(ROOT/'deploy/docker-compose.yml').read_text()
    self.assertIn('privatefiles:',yml)
    self.assertNotIn('5432:5432',yml)
    self.assertIn('80:80',yml)
    self.assertIn('443:443',yml)
    self.assertIn('DB_BOOTSTRAP', (ROOT/'deploy/start.sh').read_text())

if __name__=='__main__':unittest.main()
