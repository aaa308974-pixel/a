import {NextRequest} from 'next/server';
import {getAuthToken} from '@/platform/vendure/auth-token';
export const runtime = 'nodejs';

export async function GET(req: NextRequest) {
  const productId = req.nextUrl.searchParams.get('productId') || '';
  if (!/^\d{1,18}$/.test(productId)) return new Response('Invalid product ID', {status:400});
  const token = await getAuthToken();
  if (!token) return new Response('Authentication required', {status:401, headers:{'Cache-Control':'no-store'}});
  const url = process.env.VENDURE_SHOP_API_URL;
  if(!url)return new Response('Store unavailable', {status:503});
  try {
    const res = await fetch(url,{
      method:'POST',cache:'no-store', headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`,
        'vendure-token':process.env.VENDURE_CHANNEL_TOKEN||'__default_channel__'},
      body:JSON.stringify({query:'query Download($id: ID!){rsvx7DownloadFile(productId: $id){fileName mime base64}}',variables:{id:productId}}),
    });
    if (!res.ok)return new Response('Download service unavailable',{status:503});
    const json=await res.json();
    if(json.errors?.length || !json.data?.rsvx7DownloadFile)return new Response('Download denied or unavailable',{status:403});
    const file=json.data.rsvx7DownloadFile;
    const data=Buffer.from(file.base64,'base64');
    if(data.length>12*1024*1024)return new Response('File too large',{status:503});
    const name=String(file.fileName||'download.zip').replace(/[^A-Za-z0-9.()+_-]/g,'_').slice(0,140);
    return new Response(data,{status:200,headers:{
      'Content-Type':file.mime==='application/x-7z-compressed'?'application/x-7z-compressed':'application/zip',
      'Content-Disposition':`attachment; filename="${name}"`,
      'Content-Length':String(data.length),
      'Cache-Control':'private, no-store, max-age=0',
      'X-Content-Type-Options':'nosniff',
      'Content-Security-Policy':"default-src 'none'; sandbox",
    }});
  }catch{return new Response('Download service unavailable',{status:503});}
}
