import {Suspense} from 'react';
import {getAuthToken} from '@/platform/vendure/auth-token';
import {Link} from '@/platform/i18n/navigation';

async function DownloadList() {
  const token = await getAuthToken();
  if (!token) return <p>Please <Link className="underline text-primary" href="/sign-in?redirectTo=%2Fdownloads">sign in</Link> to view your purchases.</p>;
  const url = process.env.VENDURE_SHOP_API_URL;
  if (!url) return <p>Store connection is not configured.</p>;
  try {
    const res = await fetch(url, {
      method:'POST',cache:'no-store',headers:{'Content-Type':'application/json','Authorization':`Bearer ${token}`,
        'vendure-token':process.env.VENDURE_CHANNEL_TOKEN||'__default_channel__'},
      body:JSON.stringify({query:'{ rsvx7MyDownloads { productId fileName sizeBytes sha256 } }'}),
    });
    if (!res.ok) throw new Error('Service unavailable');
    const json = await res.json();
    if(json.errors?.length) throw new Error('Cannot load downloads');
    const items = json.data?.rsvx7MyDownloads as Array<{productId:string;fileName:string;sizeBytes:number}>|undefined;
    if(!items?.length) return <p className="text-muted-foreground mt-8">No purchased files yet.</p>;
    return <div className="grid gap-4 mt-8">{items.map(item=><div key={item.productId} className="border rounded-xl bg-card p-6 flex flex-wrap gap-3 items-center justify-between">
      <div><div className="font-bold">{item.fileName}</div><div className="text-sm text-muted-foreground">{(item.sizeBytes/1048576).toFixed(2)} MiB · Purchased</div></div>
      <a className="rounded-md bg-primary text-primary-foreground px-5 py-2 font-semibold" href={'/api/rsvx7-download?productId='+encodeURIComponent(item.productId)}>Download</a>
    </div>)}</div>;
  } catch {return <p role="alert">Downloads temporarily unavailable. Please try again later.</p>;}
}
export default function DownloadsPage() {return <main className="container mx-auto max-w-5xl pt-32 pb-24 min-h-[75vh] px-4"><h1 className="text-4xl font-bold">My Downloads</h1>
  <p className="text-muted-foreground mt-3">Files from your completed purchases, tied to your account.</p>
  <Suspense fallback={<p className="mt-5">Loading your purchases…</p>}><DownloadList/></Suspense></main>;}
