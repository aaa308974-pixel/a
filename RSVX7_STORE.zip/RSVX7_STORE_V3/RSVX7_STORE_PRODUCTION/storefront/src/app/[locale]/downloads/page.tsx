export const instant = false;
export {default} from '@/site/downloads/page';
