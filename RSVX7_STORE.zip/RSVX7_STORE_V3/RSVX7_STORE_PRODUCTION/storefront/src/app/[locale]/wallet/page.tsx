// Next.js 16.3 Cache Components: personalized wallet intentionally runs per request.
// This prevents `cookies()` being read outside a dynamic boundary.
export const instant = false;
export {default} from '@/site/wallet/page';
