import { Link } from '@/platform/i18n/navigation';
import { ArrowRight, ShieldCheck, Code2, Download, TerminalSquare, LockKeyhole, CreditCard } from 'lucide-react';

export async function HeroSection() {
  return (
    <section className="rsvx-hero relative isolate overflow-hidden border-b border-border">
      <div className="rsvx-grid absolute inset-0 pointer-events-none" aria-hidden="true" />
      <div className="rsvx-hero-glow" aria-hidden="true" />
      <div className="container relative mx-auto grid min-h-[680px] items-center gap-16 px-5 py-24 lg:grid-cols-2 lg:py-32">
        <div className="max-w-2xl">
          <span className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/25 bg-primary/10 px-4 py-2 text-xs font-bold tracking-widest text-primary">
            <span className="size-2 rounded-full bg-primary shadow-[0_0_14px_#ee334e]" />
            SECURITY SOFTWARE MARKETPLACE
          </span>
          <h1 className="text-balance text-5xl font-black leading-[1.12] tracking-tight sm:text-6xl xl:text-7xl">
            Your digital edge. <span className="rsvx-gradient-text block">Built for security.</span>
          </h1>
          <p className="mt-7 max-w-xl text-base leading-8 text-muted-foreground sm:text-lg">
            A focused marketplace for cybersecurity learning, defensive utilities, network diagnostics and professional digital resources.
          </p>
          <div className="mt-9 flex flex-wrap gap-4">
            <Link href="/search" className="rsvx-cta inline-flex items-center gap-3 rounded-lg px-6 py-3.5 font-bold text-white transition hover:-translate-y-0.5">
              Explore products <ArrowRight className="size-5" />
            </Link>
            <Link href="/wallet" className="inline-flex items-center gap-3 rounded-lg border border-border bg-card px-6 py-3.5 font-semibold transition hover:border-primary/50">
              USD Wallet <CreditCard className="size-5 text-primary" />
            </Link>
          </div>
          <div className="mt-12 grid max-w-lg grid-cols-3 gap-3">
            <div className="rsvx-stat"><ShieldCheck className="mb-3 size-5 text-primary"/><span className="text-sm font-semibold">Curated resources</span></div>
            <div className="rsvx-stat"><LockKeyhole className="mb-3 size-5 text-primary"/><span className="text-sm font-semibold">Account access</span></div>
            <div className="rsvx-stat"><Download className="mb-3 size-5 text-primary"/><span className="text-sm font-semibold">Digital catalog</span></div>
          </div>
        </div>
        <div className="relative hidden lg:block" aria-hidden="true">
          <div className="rsvx-preview-panel overflow-hidden rounded-2xl border border-rose-900/40 bg-[#13131b] shadow-[0_40px_100px_#000a,0_0_90px_#d91f3c15]">
            <div className="flex items-center justify-between border-b border-white/10 bg-[#1d1821] px-5 py-3 text-xs text-rose-400">
              <div className="flex gap-2"><span className="size-2.5 rounded-full bg-rose-500"/><span className="size-2.5 rounded-full bg-yellow-500"/><span className="size-2.5 rounded-full bg-green-500"/></div>
              <span className="font-mono tracking-widest">RSVX7 / DIGITAL MARKET</span>
              <TerminalSquare className="size-4"/>
            </div>
            <div className="p-9">
              <p className="mb-7 font-mono text-xs tracking-widest text-muted-foreground">// SYSTEM CATALOG</p>
              <div className="flex items-center gap-5 rounded-xl border border-white/10 bg-[#181821] p-5">
                <div className="grid size-16 shrink-0 place-items-center rounded-lg bg-rose-500/10 text-primary"><Code2 className="size-8"/></div>
                <div><p className="text-lg font-bold">Security resources</p><p className="text-sm text-muted-foreground">Digital tools & documentation</p></div>
              </div>
              <div className="mt-4 rounded-xl border border-white/10 bg-[#181821] p-5 font-mono text-sm leading-9">
                <p className="text-muted-foreground">$ connect --store rsvx7</p>
                <p className="text-emerald-400">✓ Marketplace initialized</p>
                <p className="text-emerald-400">✓ USD wallet enabled</p>
                <p className="text-rose-400">$ discover --catalog _</p>
              </div>
            </div>
            <div className="border-t border-white/10 bg-[#111117] p-4 text-center font-mono text-xs tracking-wider text-muted-foreground">RSVX7 STORE // PROFESSIONAL DIGITAL MARKETPLACE</div>
          </div>
          <div className="absolute -bottom-7 -right-5 -z-10 h-48 w-48 rounded-full bg-rose-600/20 blur-3xl" />
        </div>
      </div>
    </section>
  );
}
