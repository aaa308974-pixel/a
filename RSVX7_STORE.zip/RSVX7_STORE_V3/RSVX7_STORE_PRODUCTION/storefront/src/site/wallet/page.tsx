import { Suspense } from 'react';
import { getAuthToken } from '@/platform/vendure/auth-token';
import { Link } from '@/platform/i18n/navigation';

async function loadWallet() {
  const token = await getAuthToken();
  if (!token) return null;
  const apiUrl = process.env.VENDURE_SHOP_API_URL || process.env.NEXT_PUBLIC_VENDURE_SHOP_API_URL;
  if (!apiUrl) throw new Error('VENDURE_SHOP_API_URL is not configured');
  const response = await fetch(apiUrl, {
    method: 'POST',
    cache: 'no-store',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      'vendure-token': process.env.VENDURE_CHANNEL_TOKEN || '__default_channel__',
    },
    body: JSON.stringify({query: '{ rsvx7MyWallet { currency balanceCents } }'}),
  });
  if (!response.ok) throw new Error('Wallet service is unavailable');
  const result = await response.json();
  if (result.errors) throw new Error(result.errors[0]?.message || 'Could not load wallet');
  return result.data?.rsvx7MyWallet as { currency: string; balanceCents: number } | undefined;
}

async function WalletCard() {
  let wallet: { currency: string; balanceCents: number } | null | undefined;
  let problem = '';
  try { wallet = await loadWallet(); }
  catch { problem = 'Wallet service is unavailable. Check that the Vendure wallet plugin is installed.'; }
  return (
    <>
      <div className="text-xs font-bold tracking-[.25em] text-primary">RSVX7 / ACCOUNT</div>
      <h1 className="mt-4 text-4xl font-black md:text-5xl">USD <span className="text-primary">Wallet</span></h1>
      <p className="mt-3 text-muted-foreground">Use your account balance to purchase digital products instantly.</p>
      <div className="mt-10 rounded-2xl border border-border bg-card p-8 shadow-xl">
        {problem ? <p role="alert" className="text-destructive">{problem}</p>
          : wallet ? <><p className="text-sm text-muted-foreground">AVAILABLE BALANCE</p>
             <p className="mt-2 text-5xl font-black tracking-tight">${(wallet.balanceCents / 100).toFixed(2)} <span className="text-base font-medium text-muted-foreground">USD</span></p>
             <p className="mt-6 text-sm text-muted-foreground">Funds can only be added by the store administrator. No online top-up is enabled.</p></>
          : <><p className="mb-4 text-muted-foreground">Sign in to view your wallet.</p>
             <Link className="inline-block rounded-md bg-primary px-5 py-3 font-bold text-primary-foreground" href="/sign-in?redirectTo=%2Fwallet">Sign in</Link></>}
      </div>
    </>
  );
}

export default function WalletPage() {
  return (
    <main className="container mx-auto min-h-[70vh] max-w-4xl px-4 pt-36 pb-24">
      <Suspense fallback={<p className="text-muted-foreground">Loading wallet...</p>}>
        <WalletCard />
      </Suspense>
      <div className="mt-7"><Link href="/search" className="text-primary hover:underline">Explore products →</Link></div>
    </main>
  );
}

