import { Link } from '@/platform/i18n/navigation';

export function Footer() {
  return (
    <footer className="mt-auto border-t border-border bg-[#0d0d12]">
      <div className="container mx-auto grid gap-10 px-6 py-14 md:grid-cols-3">
        <div><Link href="/" className="rsvx7-brand text-2xl">RSVX7 <em>STORE</em></Link>
          <p className="mt-4 max-w-sm text-sm leading-7 text-muted-foreground">Digital utilities, cybersecurity learning resources and tools for authorized defensive work.</p></div>
        <div><p className="font-semibold">Marketplace</p><div className="mt-4 flex flex-col gap-3 text-sm text-muted-foreground"><Link href="/search">Browse products</Link><Link href="/cart">Cart</Link><Link href="/wallet">USD wallet</Link></div></div>
        <div><p className="font-semibold">Account</p><div className="mt-4 flex flex-col gap-3 text-sm text-muted-foreground"><Link href="/sign-in">Sign in</Link><Link href="/register">Create account</Link><Link href="/account/orders">My orders</Link></div></div>
      </div>
      <div className="container mx-auto border-t border-border px-6 py-5 text-xs text-muted-foreground">© 2026 RSVX7 STORE. All rights reserved.</div>
    </footer>
  );
}
