import type {Locale} from './routing';
export function toOgLocale(_locale: string): string {return 'en_US';}
export function toIntlLocale(_locale: string): string {return 'en-US';}
