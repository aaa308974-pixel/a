#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ ! -f .env ]]; then echo 'Missing .env'; exit 1; fi
source .env
curl --fail --silent --show-error --max-time 20 "https://${SITE_DOMAIN}/health" || exit 1
printf '\nHomepage HTTP status: '
curl -s -o /dev/null -w '%{http_code}\n' --max-time 20 "https://${SITE_DOMAIN}/en"
echo 'Additional manual checks: admin login; empty catalog; create product; top-up; purchase; download; access denied as guest; duplicate payment.'
