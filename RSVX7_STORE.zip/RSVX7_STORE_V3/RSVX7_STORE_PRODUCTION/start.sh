#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v docker >/dev/null 2>&1; then echo 'Docker Engine + compose plugin is required'; exit 1; fi
if [[ ! -f .env ]]; then cp .env.example .env; chmod 600 .env; echo 'Edit .env, then rerun ./start.sh'; exit 1; fi
if grep -q 'REPLACE_WITH\|store.example.com' .env; then echo 'Replace all placeholders in .env';exit 1;fi
# The .env file is user-owned; do not print secrets or put them on command lines.
set -a
# shellcheck source=/dev/null
source ./.env
set +a
[[ "$SITE_URL" == "https://$SITE_DOMAIN" ]] || { echo 'SITE_URL must match https://SITE_DOMAIN'; exit 1; }
[[ ${#SUPERADMIN_PASSWORD} -ge 16 && ${#COOKIE_SECRET} -ge 32 && ${#DB_PASSWORD} -ge 16 && ${#REVALIDATION_SECRET} -ge 32 ]] || { echo 'Use strong unique passwords and secret';exit 1; }
docker compose up -d --wait db
echo 'Building images…'
docker compose build backend storefront
# Only bootstrap an entirely new PostgreSQL DB. Never run schema synchronize on an existing store.
tables=$(docker compose exec -T db psql -U "$DB_USERNAME" -d "$DB_NAME" -Atqc "select count(*) from information_schema.tables where table_schema = 'public' and table_name = 'channel';" || echo ERROR)
if [[ "$tables" == "0" ]]; then
  echo 'Initializing EMPTY catalog and admin account (first install only)…'
  docker compose run --rm -e DB_BOOTSTRAP=1 backend node dist/initialize-empty.js
elif [[ "$tables" != "1" ]]; then
  echo "Database check failed: $tables"; exit 1
fi
docker compose up -d backend worker storefront caddy
echo "RSVX7 storefront: $SITE_URL"
echo "Vendure dashboard: $SITE_URL/dashboard"
echo 'Inspect startup logs: docker compose logs -f backend worker storefront caddy'
