/** First-time database initialization: NO products, customers, sample purchases or dummy payments.
 * Run once only when the PostgreSQL schema is empty. Never use to reset an existing database.
 */
import {bootstrap, LanguageCode} from '@vendure/core';
import {populate} from '@vendure/core/cli';
import {config} from './vendure-config';

async function main() {
  if (process.env.DB_BOOTSTRAP !== '1' || !process.env.DB_HOST) {
    throw new Error('EMPTY_DATABASE_BOOTSTRAP_ONLY');
  }
  const initialData = {
    defaultLanguage: LanguageCode.en,
    defaultZone: 'Worldwide',
    countries: [
      {name:'Turkey',code:'TR',zone:'Worldwide'},
      {name:'United States',code:'US',zone:'Worldwide'},
      {name:'Germany',code:'DE',zone:'Worldwide'},
      {name:'United Kingdom',code:'GB',zone:'Worldwide'},
      {name:'Syria',code:'SY',zone:'Worldwide'},
    ],
    taxRates: [{name:'Digital Goods (review tax settings)',percentage:0}],
    shippingMethods: [{name:'Digital download',price:0}],
    paymentMethods: [{name:'RSVX7 USD Wallet',handler:{code:'rsvx7-wallet',arguments:[]}}],
    collections: [],
  };
  const app=await populate(()=>bootstrap(config), initialData);
  await app.close();
}
main().then(()=>process.exit(0)).catch(e=>{console.error(e);process.exit(1);});
