import { Rsvx7StorePlugin } from './plugins/rsvx7-store/store.plugin';
import { json as rsvx7Json } from 'express';
import {
    dummyPaymentHandler,
    DefaultJobQueuePlugin,
    DefaultSchedulerPlugin,
    DefaultSearchPlugin,
    VendureConfig,
} from '@vendure/core';
import { defaultEmailHandlers, EmailPlugin, FileBasedTemplateLoader } from '@vendure/email-plugin';
import { AssetServerPlugin } from '@vendure/asset-server-plugin';
import { DashboardPlugin } from '@vendure/dashboard/plugin';
import { GraphiqlPlugin } from '@vendure/graphiql-plugin';
import 'dotenv/config';
import path from 'path';

const IS_DEV = process.env.APP_ENV === 'dev';
// PORT wins because hosting platforms inject it into the environment at runtime, and that
// must take precedence over any value baked into the .env file at scaffold time.
const serverPort = +process.env.PORT || +process.env.VENDURE_SERVER_PORT || 3000;

export const config: VendureConfig = {
    apiOptions: {
        port: serverPort,
        adminApiPath: 'admin-api',
        shopApiPath: 'shop-api',
        trustProxy: IS_DEV ? false : 1,
        // Which browser origins may make credentialed requests to the Shop and Admin APIs.
        // In dev any origin is reflected, so a storefront on any port works. In production set
        // CORS_ORIGINS to a comma-separated list of the origins you serve, for example
        // "https://example.com,https://admin.example.com". An unset value blocks all
        // cross-origin browser requests, which is the safe default.
        cors: {
            origin: IS_DEV ? true : (process.env.CORS_ORIGINS?.split(',').map(o => o.trim()).filter(Boolean) ?? []),
            credentials: true,
        },
    },
    authOptions: {
        tokenMethod: ['bearer', 'cookie'],
        superadminCredentials: {
            identifier: process.env.SUPERADMIN_USERNAME,
            password: process.env.SUPERADMIN_PASSWORD,
        },
        cookieOptions: {
          secret: process.env.COOKIE_SECRET,
        },
    },
    dbConnectionOptions: {
        type: 'better-sqlite3',
        // See the README.md "Migrations" section for an explanation of
        // the `synchronize` and `migrations` options.
        synchronize: false,
        migrations: [path.join(__dirname, './migrations/*.+(js|ts)')],
        logging: false,
        database: path.join(__dirname, '../vendure.sqlite'),
    },
    paymentOptions: {
        paymentMethodHandlers: [dummyPaymentHandler],
    },
    // When adding or altering custom field definitions, the database will
    // need to be updated. See the "Migrations" section in README.md.
    customFields: {},
    plugins: [
        GraphiqlPlugin.init(),
        AssetServerPlugin.init({
            route: 'assets',
            assetUploadDir: path.join(__dirname, '../static/assets'),
            // For local dev, the correct value for assetUrlPrefix should
            // be guessed correctly, but for production it will usually need
            // to be set manually to match your production url.
            assetUrlPrefix: IS_DEV ? undefined : (process.env.SITE_URL || 'http://localhost:3001') + '/assets/',
        }),
        DefaultSchedulerPlugin.init(),
        DefaultJobQueuePlugin.init({ useDatabaseForBuffer: true }),
        DefaultSearchPlugin.init({ bufferUpdates: false, indexStockStatus: true }),
        EmailPlugin.init({
            devMode: true,
            outputPath: path.join(__dirname, '../static/email/test-emails'),
            route: 'mailbox',
            handlers: defaultEmailHandlers,
            templateLoader: new FileBasedTemplateLoader(path.join(__dirname, '../static/email/templates')),
            globalTemplateVars: {
                // The following variables will change depending on your storefront implementation.
                // No storefront was created, so port 3001 is only a placeholder:
                // nothing is listening on it until you point these at your own storefront.
                fromAddress: '"example" <noreply@example.com>',
                verifyEmailAddressUrl: 'http://localhost:3001/verify',
                passwordResetUrl: 'http://localhost:3001/reset-password',
                changeEmailAddressUrl: 'http://localhost:3001/account/verify-email',
                // The URL of the password reset page of the Vendure Dashboard.
                adminPasswordResetUrl: `http://localhost:${serverPort}/dashboard/reset-password`
            },
        }),
        DashboardPlugin.init({
            route: 'dashboard',
            appDir: IS_DEV
                ? path.join(__dirname, '../dist/dashboard')
                : path.join(__dirname, 'dashboard'),
        }),
    ],
};

// RSVX7-V3-PRODUCTION-SETTINGS
// Environment-file-only configuration; no secrets in the repository.
const live = process.env.NODE_ENV === 'production' && process.env.RSVX7_RUNTIME === '1';
if (live && (!process.env.COOKIE_SECRET || !process.env.SUPERADMIN_PASSWORD ||
             process.env.SUPERADMIN_PASSWORD === 'superadmin')) {
  throw new Error('Set strong COOKIE_SECRET and SUPERADMIN_PASSWORD before launching production.');
}
config.authOptions = {
  ...config.authOptions,
  tokenMethod: ['cookie', 'bearer'],
  cookieOptions: {...config.authOptions.cookieOptions,
    secret: process.env.COOKIE_SECRET || 'local-testing-change-this-secret',
    sameSite: 'lax', secure: live, httpOnly: true },
  superadminCredentials: {
    identifier: process.env.SUPERADMIN_USERNAME || 'superadmin',
    password: process.env.SUPERADMIN_PASSWORD || 'superadmin',
  },
  requireVerification: false,
};
config.apiOptions = {
  ...config.apiOptions,
  port: 3000,
  hostname: '0.0.0.0',
  cors: {origin: (process.env.SITE_URL || 'http://localhost:3001'), credentials:true},
  csrfPrevention: live,
  introspection: !live,
  adminApiPlayground: !live,
  shopApiPlayground: !live,
  middleware: [...(config.apiOptions.middleware || []),
    {handler: rsvx7Json({limit:'17mb'}), route:'/admin-api', beforeListen:true}],
};
if (process.env.DB_HOST) {
  config.dbConnectionOptions = {
    type: 'postgres', host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT || 5432),
    username: process.env.DB_USERNAME, password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME || 'rsvx7',
    synchronize: process.env.DB_BOOTSTRAP === '1',
    logging: false,
  };
}
config.plugins = [...(config.plugins || []), Rsvx7StorePlugin];
