import { Injectable } from '@nestjs/common';
import { createHash, randomUUID } from 'node:crypto';
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { basename, join, resolve } from 'node:path';
import { Customer, Order, Product, RequestContext, TransactionalConnection } from '@vendure/core';
import { Rsvx7DigitalFile } from './digital.entity';

const MAX_ARCHIVE_BYTES = 12 * 1024 * 1024; // GraphQL base64, deliberately limited
const PRIVATE_ROOT = resolve(process.env.RSVX7_PRIVATE_DIR || './private-files');

function assertArchive(bytes: Buffer, fileName: string) {
  if (!Number.isSafeInteger(bytes.length) || bytes.length < 6 || bytes.length > MAX_ARCHIVE_BYTES) throw new Error('ARCHIVE_SIZE_LIMIT_12_MB');
  if (fileName.length > 180 || !/^[\w .()+-]+\.(zip|7z)$/i.test(fileName)) throw new Error('ARCHIVE_FILENAME_INVALID');
  const zip = bytes.subarray(0, 4).equals(Buffer.from('504b0304', 'hex'));
  const sevenZip = bytes.subarray(0, 6).equals(Buffer.from('377abcaf271c', 'hex'));
  if (!zip && !sevenZip) throw new Error('NOT_AN_ARCHIVE');
  if (fileName.toLowerCase().endsWith('.zip') !== zip) throw new Error('ARCHIVE_EXTENSION_MISMATCH');
}

@Injectable()
export class Rsvx7DigitalService {
  constructor(private readonly connection: TransactionalConnection) {}

  async upload(ctx: RequestContext, productId: string, fileName: string, base64: string) {
    // @Allow(UpdateCatalog) restricts resolver; verify target is a real catalog item.
    if (base64.length > Math.ceil(MAX_ARCHIVE_BYTES * 4 / 3) + 4 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(base64)) {
      throw new Error('INVALID_BASE64_OR_ARCHIVE_TOO_LARGE');
    }
    const bytes = Buffer.from(base64, 'base64');
    const safeName = basename(fileName);
    assertArchive(bytes, safeName);
    const product = await this.connection.getRepository(ctx, Product).findOne({ where: { id: productId } });
    if (!product) throw new Error('PRODUCT_NOT_FOUND');

    const diskName = randomUUID() + (safeName.toLowerCase().endsWith('.7z') ? '.7z' : '.zip');
    const sha256 = createHash('sha256').update(bytes).digest('hex');
    await mkdir(PRIVATE_ROOT, { recursive: true, mode: 0o700 });
    await writeFile(join(PRIVATE_ROOT, diskName), bytes, { flag: 'wx', mode: 0o600 });
    try {
      const repo = this.connection.getRepository(ctx, Rsvx7DigitalFile);
      const existing = await repo.findOne({ where: { productId } });
      const oldName = existing?.diskName;
      await repo.save(repo.create({ ...(existing || {}), productId, diskName, originalName: safeName, sizeBytes: bytes.length, sha256 }));
      // Old archive is removed after metadata commits; old files are private but can be cleaned by maintenance.
      if (oldName && oldName !== diskName) await rm(join(PRIVATE_ROOT, oldName), { force: true }).catch(() => {});
    } catch (err) {
      await rm(join(PRIVATE_ROOT, diskName), { force: true }).catch(() => {});
      throw err;
    }
    return { productId, fileName: safeName, sizeBytes: bytes.length, sha256 };
  }

  async remove(ctx: RequestContext, productId: string) {
    const repo = this.connection.getRepository(ctx, Rsvx7DigitalFile);
    const existing = await repo.findOne({ where: { productId } });
    if (!existing) return true;
    await repo.remove(existing);
    await rm(join(PRIVATE_ROOT, existing.diskName), { force: true }).catch(() => {});
    return true;
  }

  async list(ctx: RequestContext) {
    const rows = await this.connection.getRepository(ctx, Rsvx7DigitalFile).find({ order: { createdAt: 'DESC' }, take: 500 });
    return rows.map(x => ({ productId: x.productId, fileName: x.originalName, sizeBytes: x.sizeBytes, sha256: x.sha256 }));
  }

  private async currentCustomer(ctx: RequestContext): Promise<Customer> {
    if (!ctx.activeUserId) throw new Error('LOGIN_REQUIRED');
    const customer = await this.connection.getRepository(ctx, Customer).findOne({ where: { user: { id: ctx.activeUserId } }, relations: ['user'] });
    if (!customer) throw new Error('LOGIN_REQUIRED');
    return customer;
  }

  private async paidProductIds(ctx: RequestContext): Promise<Set<string>> {
    const customer = await this.currentCustomer(ctx);
    const orders = await this.connection.getRepository(ctx, Order).find({
      where: { customer: { id: customer.id } },
      relations: ['payments', 'lines', 'lines.productVariant', 'lines.productVariant.product', 'payments.refunds'],
      take: 1000,
    });
    const owned = new Set<string>();
    for (const order of orders) {
      // Refunded purchases do not grant access. All payment methods other than the wallet should be disabled.
      const successful = (order.payments ?? []).filter(p => p.state === 'Settled' && p.method === 'rsvx7-wallet');
      const paidCents = successful.reduce((sum, p) => sum + p.amount, 0);
      const refundedCents = successful.flatMap(p => p.refunds || []).filter(r => r.state === 'Settled').reduce((sum, r) => sum + r.total, 0);
      if (!order.orderPlacedAt || paidCents - refundedCents < order.totalWithTax || order.totalWithTax <= 0) continue;
      for (const line of order.lines) {
        const productId = line.productVariant?.product?.id;
        if (productId) owned.add(String(productId));
      }
    }
    return owned;
  }

  async myDownloads(ctx: RequestContext) {
    const owned = await this.paidProductIds(ctx);
    if (!owned.size) return [];
    const rows = await this.connection.getRepository(ctx, Rsvx7DigitalFile).find();
    return rows.filter(x => owned.has(String(x.productId))).map(x => ({productId: x.productId, fileName: x.originalName, sizeBytes: x.sizeBytes, sha256: x.sha256}));
  }

  async download(ctx: RequestContext, productId: string) {
    const owned = await this.paidProductIds(ctx);
    if (!owned.has(String(productId))) throw new Error('NO_PAID_PURCHASE');
    const row = await this.connection.getRepository(ctx, Rsvx7DigitalFile).findOne({ where: { productId } });
    if (!row) throw new Error('DIGITAL_FILE_NOT_FOUND');
    const contents = await readFile(join(PRIVATE_ROOT, row.diskName));
    if (createHash('sha256').update(contents).digest('hex') !== row.sha256) throw new Error('FILE_INTEGRITY_FAILURE');
    return { fileName: row.originalName, mime: row.originalName.toLowerCase().endsWith('.zip') ? 'application/zip' : 'application/x-7z-compressed', base64: contents.toString('base64') };
  }
}
