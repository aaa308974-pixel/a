import { Column, Entity, Index } from 'typeorm';
import { VendureEntity } from '@vendure/core';

@Entity('rsvx7_digital_file')
@Index(['productId'], { unique: true })
export class Rsvx7DigitalFile extends VendureEntity {
  @Column({ type: 'varchar', length: 128 }) productId!: string;
  @Column({ type: 'varchar', length: 80 }) diskName!: string;
  @Column({ type: 'varchar', length: 180 }) originalName!: string;
  @Column({ type: 'varchar', length: 64 }) sha256!: string;
  @Column({ type: 'integer' }) sizeBytes!: number;
}
