import { Column, Entity, Index } from 'typeorm';
import { VendureEntity } from '@vendure/core';

@Entity('rsvx7_wallet')
@Index(['customerId'], { unique: true })
export class Rsvx7Wallet extends VendureEntity {
  @Column({ type: 'varchar', length: 128 })
  customerId!: string;

  /** Amount is stored as an integer number of US cents. */
  @Column({ type: 'integer', default: 0 })
  balanceCents!: number;
}

@Entity('rsvx7_wallet_entry')
@Index(['reference'], { unique: true })
export class Rsvx7WalletEntry extends VendureEntity {
  @Column({ type: 'varchar', length: 128 })
  customerId!: string;

  @Column({ type: 'integer' })
  deltaCents!: number;

  @Column({ type: 'integer' })
  balanceAfterCents!: number;

  @Column({ type: 'varchar', length: 240 })
  reference!: string;

  @Column({ type: 'varchar', length: 240 })
  memo!: string;

  @Column({ type: 'varchar', length: 128, nullable: true })
  actorUserId?: string;
}
