import { Args, Mutation, Query, Resolver } from '@nestjs/graphql';
import {
  Allow, Ctx, LanguageCode, PaymentMethodHandler, Permission,
  PluginCommonModule, RequestContext, VendurePlugin,
} from '@vendure/core';
import gql from 'graphql-tag';
import { Rsvx7Wallet, Rsvx7WalletEntry } from './wallet.entity';
import { Rsvx7WalletService } from './wallet.service';
import { Rsvx7DigitalFile } from './digital.entity';
import { Rsvx7DigitalService } from './digital.service';

const types = `
  type Rsvx7WalletBalance { currency: String! balanceCents: Int! }
  type Rsvx7WalletLedgerEntry { deltaCents: Int! balanceAfterCents: Int! reference: String! memo: String! actorUserId: String createdAt: String! }
  type Rsvx7DigitalRecord { productId: ID! fileName: String! sizeBytes: Int! sha256: String! }
  type Rsvx7DigitalPayload { fileName: String! mime: String! base64: String! }
`;

@Resolver()
class ShopResolver {
  constructor(private readonly wallet: Rsvx7WalletService, private readonly files: Rsvx7DigitalService) {}
  @Allow(Permission.Authenticated) @Query()
  rsvx7MyWallet(@Ctx() ctx: RequestContext) {return this.wallet.myBalance(ctx);}
  @Allow(Permission.Authenticated) @Query()
  rsvx7MyDownloads(@Ctx() ctx: RequestContext) {return this.files.myDownloads(ctx);}
  @Allow(Permission.Authenticated) @Query()
  rsvx7DownloadFile(@Ctx() ctx: RequestContext, @Args('productId') productId: string) {return this.files.download(ctx, productId);}
}

@Resolver()
class AdminResolver {
  constructor(private readonly wallet: Rsvx7WalletService, private readonly files: Rsvx7DigitalService) {}
  @Allow(Permission.SuperAdmin) @Query()
  rsvx7CustomerWallet(@Ctx() ctx: RequestContext, @Args('customerId') customerId: string) {return this.wallet.getBalance(ctx, customerId);}
  @Allow(Permission.SuperAdmin) @Query()
  rsvx7WalletHistory(@Ctx() ctx: RequestContext, @Args('customerId') customerId: string) {return this.wallet.history(ctx, customerId);}
  @Allow(Permission.SuperAdmin) @Mutation()
  rsvx7AdjustWallet(@Ctx() ctx: RequestContext, @Args('customerId') customerId: string,
                    @Args('deltaCents') deltaCents: number, @Args('reference') reference: string,
                    @Args('memo') memo: string) {return this.wallet.adjust(ctx, customerId, deltaCents, reference, memo);}
  @Allow(Permission.SuperAdmin) @Query()
  rsvx7Files(@Ctx() ctx: RequestContext) {return this.files.list(ctx);}
  @Allow(Permission.SuperAdmin) @Mutation()
  rsvx7UploadArchive(@Ctx() ctx: RequestContext, @Args('productId') productId: string,
                     @Args('fileName') fileName: string, @Args('base64') base64: string) {
    return this.files.upload(ctx, productId, fileName, base64);
  }
  @Allow(Permission.SuperAdmin) @Mutation()
  rsvx7RemoveArchive(@Ctx() ctx: RequestContext, @Args('productId') productId: string) {return this.files.remove(ctx, productId);}
}

let walletService: Rsvx7WalletService;
export const rsvx7WalletHandler = new PaymentMethodHandler({
  code: 'rsvx7-wallet',
  description: [{languageCode: LanguageCode.en, value: 'RSVX7 USD Wallet - manually funded'}],
  args: {},
  init: injector => {walletService = injector.get(Rsvx7WalletService);},
  createPayment: async (ctx, order, amount) => {
    try {
      const debit = await walletService.debitOrder(ctx, order, amount);
      return {amount, state: 'Settled' as const, transactionId: debit.reference,
        metadata: {balanceAfterCents: debit.balanceCents}};
    } catch (error) {
      const code = error instanceof Error ? error.message : 'PAYMENT_ERROR';
      return {amount, state: 'Error' as const,
        errorMessage: ['LOGIN_REQUIRED', 'USD_ONLY', 'ORDER_NOT_OWNED',
          'INSUFFICIENT_WALLET_BALANCE', 'ORDER_CUSTOMER_REQUIRED',
          'ORDER_DEBIT_MISMATCH'].includes(code) ? code : 'PAYMENT_ERROR'};
    }
  },
  settlePayment: async () => ({success: true}),
  // Refunds are manual and must credit the wallet via the audited admin adjustment action.
  // Never tell Vendure a refund was applied unless it was actually recorded.
});

@VendurePlugin({
  imports: [PluginCommonModule],
  entities: [Rsvx7Wallet, Rsvx7WalletEntry, Rsvx7DigitalFile],
  providers: [Rsvx7WalletService, Rsvx7DigitalService],
  shopApiExtensions: {
    schema: gql`${types}
      extend type Query {
        rsvx7MyWallet: Rsvx7WalletBalance!
        rsvx7MyDownloads: [Rsvx7DigitalRecord!]!
        rsvx7DownloadFile(productId: ID!): Rsvx7DigitalPayload!
      }
    `,
    resolvers: [ShopResolver],
  },
  adminApiExtensions: {
    schema: gql`${types}
      extend type Query {
        rsvx7CustomerWallet(customerId: ID!): Rsvx7WalletBalance!
        rsvx7WalletHistory(customerId: ID!): [Rsvx7WalletLedgerEntry!]!
        rsvx7Files: [Rsvx7DigitalRecord!]!
      }
      extend type Mutation {
        rsvx7AdjustWallet(customerId: ID!, deltaCents: Int!, reference: String!, memo: String!): Rsvx7WalletBalance!
        rsvx7UploadArchive(productId: ID!, fileName: String!, base64: String!): Rsvx7DigitalRecord!
        rsvx7RemoveArchive(productId: ID!): Boolean!
      }
    `,
    resolvers: [AdminResolver],
  },
  dashboard: './dashboard/index.tsx',
  configuration: config => {
    config.authOptions.requireVerification = false;
    config.paymentOptions.paymentMethodHandlers = [rsvx7WalletHandler];
    return config;
  },
})
export class Rsvx7StorePlugin {}
