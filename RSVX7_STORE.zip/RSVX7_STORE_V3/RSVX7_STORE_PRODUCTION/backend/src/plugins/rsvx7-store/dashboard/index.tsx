import {useState} from 'react';
import {api, Button, Input, Page, PageBlock, PageLayout, PageTitle, defineDashboardExtension} from '@vendure/dashboard';
import {graphql} from '@/gql';

const walletQuery = graphql(`query Rsvx7WalletForAdmin($id: ID!) {rsvx7CustomerWallet(customerId: $id) {currency balanceCents}}`);
const historyQuery = graphql(`query Rsvx7WalletHistoryForAdmin($id: ID!) {rsvx7WalletHistory(customerId: $id) {deltaCents balanceAfterCents reference memo actorUserId createdAt}}`);
const adjustMutation = graphql(`mutation Rsvx7AdjustForAdmin($id: ID!, $delta: Int!, $ref: String!, $memo: String!) {rsvx7AdjustWallet(customerId: $id, deltaCents: $delta, reference: $ref, memo: $memo) {balanceCents currency}}`);
const uploadMutation = graphql(`mutation Rsvx7UploadForAdmin($productId: ID!, $fileName: String!, $base64: String!) {rsvx7UploadArchive(productId: $productId, fileName: $fileName, base64: $base64) {productId fileName sizeBytes sha256}}`);
const listQuery = graphql(`query Rsvx7FilesForAdmin {rsvx7Files {productId fileName sizeBytes sha256}}`);
const removeMutation = graphql(`mutation Rsvx7RemoveForAdmin($id: ID!) {rsvx7RemoveArchive(productId: $id)}`);

function WalletPage() {
  const [customerId, setCustomerId] = useState('');
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('Manual credit');
  const [balance, setBalance] = useState<number | null>(null);
  const [entries,setEntries] = useState<Array<{deltaCents:number;balanceAfterCents:number;reference:string;memo:string;actorUserId?:string|null;createdAt:string}>>([]);
  const [error, setError] = useState('');
  const [pending, setPending] = useState(false);
  async function load() {
    try {
      setError('');
      const data = await api.query(walletQuery, {id: customerId.trim()});
      setBalance(data.rsvx7CustomerWallet.balanceCents);
      const history=await api.query(historyQuery,{id:customerId.trim()});
      setEntries([...history.rsvx7WalletHistory]);
    } catch (e) {setError(String(e));}
  }
  async function submit() {
    const m = amount.trim();
    if (!/^-?\d+(?:\.\d{1,2})?$/.test(m) || Number(m) === 0) {setError('Enter a valid non-zero USD amount, at most 2 decimal places'); return;}
    if (reason.trim().length < 3) {setError('Enter an audit reason'); return;}
    const cents = Math.round(Number(m)*100);
    if (!Number.isSafeInteger(cents) || Math.abs(cents)>10_000_000) {setError('Amount too large');return;}
    if (!confirm(`${cents>=0?'CREDIT':'DEBIT'} $${(Math.abs(cents)/100).toFixed(2)} for customer ${customerId}?`)) return;
    setPending(true);
    try {
      setError('');
      const ref = 'adjust:' + crypto.randomUUID().replace(/-/g, '');
      const data = await api.mutate(adjustMutation, {id: customerId.trim(),delta: cents,ref,memo:reason});
      setBalance(data.rsvx7AdjustWallet.balanceCents);
      setAmount('');
      const history=await api.query(historyQuery,{id:customerId.trim()});setEntries([...history.rsvx7WalletHistory]);
    } catch(e) {setError(String(e));} finally {setPending(false);}
  }
  return <Page pageId="rsvx7-wallet-admin"><PageTitle>RSVX7 Wallet Management</PageTitle><PageLayout><PageBlock blockId="wallet">
    <p>Customer ID is available in Customers → customer details. Positive amount adds credit, negative deducts. Only SuperAdmin has permission.</p>
    <div className="space-y-3 max-w-xl mt-4">
      <label>Customer ID<Input value={customerId} onChange={e=>setCustomerId(e.target.value)} placeholder="Customer ID" /></label>
      <Button onClick={load} disabled={!customerId.trim()}>Check balance</Button>
      {balance!==null && <p className="text-2xl font-bold">Current balance: ${(balance/100).toFixed(2)} USD</p>}
      <label>Adjust USD (+ / -)<Input value={amount} onChange={e=>setAmount(e.target.value)} placeholder="25.00 or -5.00" /></label>
      <label>Reason<Input value={reason} onChange={e=>setReason(e.target.value)} /></label>
      <Button disabled={!customerId.trim() || pending} onClick={submit}>{pending?'Processing…':'Confirm balance adjustment'}</Button>
      {error && <p role="alert" className="text-red-500">{error}</p>}
      <h3 className="font-bold mt-8">Recent ledger entries</h3>
      <div className="space-y-2">{entries.map(e=><div key={e.reference} className="border p-2 rounded text-sm">{e.createdAt.slice(0,10)} · {e.deltaCents>=0?'+':''}${(e.deltaCents/100).toFixed(2)} · balance ${(e.balanceAfterCents/100).toFixed(2)} · {e.memo} {e.actorUserId ? `(by user ${e.actorUserId})` : ''}</div>)}</div>
    </div>
  </PageBlock></PageLayout></Page>;
}

function DigitalPage() {
  const [productId,setProductId]=useState('');
  const [file,setFile]=useState<File|null>(null);
  const [files,setFiles]=useState<Array<{productId:string;fileName:string;sizeBytes:number;sha256:string}>>([]);
  const [error,setError]=useState('');
  const [pending,setPending]=useState(false);
  const [message,setMessage]=useState('');
  async function refresh(){try {setError('');const r=await api.query(listQuery);setFiles([...r.rsvx7Files]);}catch(e){setError(String(e));}}
  async function upload(){
    if (!file || !productId.trim()) {setError('Select product ID and archive');return;}
    if(file.size>12*1024*1024 || file.size<6){setError('Archive must be below 12 MiB');return;}
    setPending(true);
    try{
      setError('');setMessage('');
      const base64 = await new Promise<string>((resolve,reject)=>{
        const reader=new FileReader();reader.onerror=()=>reject(new Error('File read failed'));
        reader.onload=()=>resolve(String(reader.result).split(',')[1]||'');reader.readAsDataURL(file);
      });
      await api.mutate(uploadMutation,{productId:productId.trim(),fileName:file.name,base64});
      setMessage(`Uploaded ${file.name} to product #${productId}`);
      await refresh();
    }catch(e){setError(String(e));}finally{setPending(false);}
  }
  async function remove(id:string){
    if(!confirm(`Remove private download for product ${id}? Buyers will no longer be able to download it.`))return;
    try{setError('');await api.mutate(removeMutation,{id});await refresh();}catch(e){setError(String(e));}
  }
  return <Page pageId="rsvx7-digital-admin"><PageTitle>Digital Product Archives</PageTitle><PageLayout><PageBlock blockId="archive">
    <p>Create a product under Catalog → Products first. Then upload a ZIP or 7z archive for its Product ID. Never upload paid archives using Vendure's public image asset uploader.</p>
    <p className="text-muted-foreground">For this initial implementation, archive size is limited to 12 MiB. Large downloads require private object storage and a streaming endpoint.</p>
    <div className="max-w-xl space-y-4 my-5"><label>Product ID<Input value={productId} onChange={e=>setProductId(e.target.value)} /></label>
      <input aria-label="Select ZIP or 7z" type="file" accept=".zip,.7z" onChange={e=>setFile(e.target.files?.[0]||null)}/>
      <Button onClick={upload} disabled={pending || !file || !productId.trim()}>{pending?'Uploading…':'Upload private archive'}</Button>
      {message && <p>{message}</p>}{error && <p role="alert" className="text-red-500">{error}</p>}
      <Button variant="outline" onClick={refresh}>Refresh archive list</Button></div>
    <div className="space-y-3">{files.map(f=><div key={f.productId} className="flex gap-3 items-center border rounded p-3">
      <span className="flex-1">Product #{f.productId}: {f.fileName} ({(f.sizeBytes/1048576).toFixed(2)} MiB)</span>
      <Button variant="destructive" onClick={()=>remove(f.productId)}>Remove</Button>
    </div>)}</div>
  </PageBlock></PageLayout></Page>;
}

defineDashboardExtension({
  routes: [
    {path:'/rsvx7-wallet',loader:()=>({breadcrumb:'Wallet Management'}),navMenuItem:{id:'rsvx7-wallet',title:'USD Wallets',sectionId:'customers'},component:WalletPage},
    {path:'/rsvx7-digital',loader:()=>({breadcrumb:'Digital Archives'}),navMenuItem:{id:'rsvx7-digital',title:'Digital Downloads',sectionId:'catalog'},component:DigitalPage},
  ],
});
