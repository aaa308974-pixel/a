import { Injectable } from '@nestjs/common';
import { Customer, Order, RequestContext, TransactionalConnection } from '@vendure/core';
import { Rsvx7Wallet, Rsvx7WalletEntry } from './wallet.entity';

const MAX_TOP_UP_CENTS = 10_000_000; // $100,000 per admin operation

@Injectable()
export class Rsvx7WalletService {
  constructor(private readonly connection: TransactionalConnection) {}

  private async getCustomerForLogin(ctx: RequestContext): Promise<Customer> {
    if (!ctx.activeUserId) throw new Error('LOGIN_REQUIRED');
    const customer = await this.connection.getRepository(ctx, Customer).findOne({
      where: { user: { id: ctx.activeUserId } },
      relations: ['user'],
    });
    if (!customer || !customer.user || String(customer.user.id) !== String(ctx.activeUserId)) {
      throw new Error('LOGIN_REQUIRED');
    }
    return customer;
  }

  async myBalance(ctx: RequestContext) {
    const customer = await this.getCustomerForLogin(ctx);
    return this.getBalance(ctx, String(customer.id));
  }

  async getBalance(ctx: RequestContext, customerId: string) {
    const wallet = await this.connection.getRepository(ctx, Rsvx7Wallet).findOne({ where: { customerId } });
    return { currency: 'USD', balanceCents: wallet?.balanceCents ?? 0 };
  }

  async history(ctx: RequestContext, customerId: string) {
    const entries = await this.connection.getRepository(ctx, Rsvx7WalletEntry).find({
      where: {customerId}, order: {createdAt: 'DESC'}, take: 50,
    });
    return entries.map(e => ({
      deltaCents: e.deltaCents, balanceAfterCents: e.balanceAfterCents,
      reference: e.reference, memo: e.memo, actorUserId: e.actorUserId || null, createdAt: e.createdAt.toISOString(),
    }));
  }

  async topUp(ctx: RequestContext, customerId: string, amountCents: number, reference: string, memo: string) {
    if (!Number.isSafeInteger(amountCents) || amountCents <= 0 || amountCents > MAX_TOP_UP_CENTS) {
      throw new Error('INVALID_TOP_UP_AMOUNT');
    }
    if (!/^topup:[a-zA-Z0-9_-]{12,128}$/.test(reference)) {
      throw new Error('INVALID_TOP_UP_REFERENCE');
    }
    if (!memo || memo.length > 200) throw new Error('INVALID_MEMO');
    const customer = await this.connection.getRepository(ctx, Customer).findOne({ where: { id: customerId } });
    if (!customer) throw new Error('CUSTOMER_NOT_FOUND');
    return this.connection.withTransaction(ctx, async tx => {
      const walletRepo = this.connection.getRepository(tx, Rsvx7Wallet);
      const entryRepo = this.connection.getRepository(tx, Rsvx7WalletEntry);
      const previous = await entryRepo.findOne({ where: { reference } });
      if (previous) {
        if (previous.customerId !== customerId || previous.deltaCents !== amountCents) {
          throw new Error('REFERENCE_ALREADY_USED');
        }
        return this.getBalance(tx, customerId);
      }
      // INSERT OR IGNORE/ON CONFLICT ensures concurrent credits create at most one wallet row.
      await walletRepo.createQueryBuilder().insert().into(Rsvx7Wallet)
        .values({ customerId, balanceCents: 0 }).orIgnore().execute();
      await walletRepo.createQueryBuilder().update(Rsvx7Wallet)
        .set({ balanceCents: () => 'balanceCents + :delta' })
        .where('customerId = :cid', { cid: customerId })
        .setParameter('delta', amountCents).execute();
      const wallet = await walletRepo.findOneOrFail({ where: { customerId } });
      await entryRepo.save(entryRepo.create({
        customerId, deltaCents: amountCents, balanceAfterCents: wallet.balanceCents,
        reference, memo: memo.trim(),
      }));
      return { currency: 'USD', balanceCents: wallet.balanceCents };
    });
  }

  // Only used by the ADMIN API resolver protected by SuperAdmin.
  async adjust(ctx: RequestContext, customerId: string, deltaCents: number, reference: string, memo: string) {
    if (!Number.isSafeInteger(deltaCents) || deltaCents === 0 || Math.abs(deltaCents) > MAX_TOP_UP_CENTS) throw new Error('INVALID_ADJUSTMENT');
    if (!/^adjust:[a-zA-Z0-9_-]{12,128}$/.test(reference)) throw new Error('INVALID_ADJUSTMENT_REFERENCE');
    if (!memo || memo.trim().length < 3 || memo.length > 200) throw new Error('INVALID_MEMO');
    const customer = await this.connection.getRepository(ctx, Customer).findOne({where: {id: customerId}});
    if (!customer) throw new Error('CUSTOMER_NOT_FOUND');
    return this.connection.withTransaction(ctx, async tx => {
      const wallets = this.connection.getRepository(tx, Rsvx7Wallet);
      const entries = this.connection.getRepository(tx, Rsvx7WalletEntry);
      const prior = await entries.findOne({where: {reference}});
      if (prior) {
        if (prior.customerId !== customerId || prior.deltaCents !== deltaCents) throw new Error('REFERENCE_ALREADY_USED');
        return this.getBalance(tx, customerId);
      }
      await wallets.createQueryBuilder().insert().into(Rsvx7Wallet).values({customerId, balanceCents: 0}).orIgnore().execute();
      const updated = await wallets.createQueryBuilder().update(Rsvx7Wallet)
        .set({balanceCents: () => 'balanceCents + :change'})
        .where('customerId = :cid AND balanceCents + :change BETWEEN 0 AND 2147483647', {cid: customerId})
        .setParameter('change', deltaCents).execute();
      if (updated.affected !== 1) throw new Error('INSUFFICIENT_BALANCE');
      const row = await wallets.findOneOrFail({where: {customerId}});
      await entries.save(entries.create({customerId, deltaCents, balanceAfterCents: row.balanceCents, reference, memo: memo.trim(), actorUserId: String(ctx.activeUserId ?? '')}));
      return {currency: 'USD', balanceCents: row.balanceCents};
    });
  }

  async debitOrder(ctx: RequestContext, order: Order, amountCents: number) {
    if (!ctx.activeUserId) throw new Error('LOGIN_REQUIRED');
    if (order.currencyCode !== 'USD') throw new Error('USD_ONLY');
    if (!Number.isSafeInteger(amountCents) || amountCents <= 0) throw new Error('INVALID_PAYMENT_AMOUNT');
    if (!order.customer?.id) throw new Error('ORDER_CUSTOMER_REQUIRED');
    const customerId = String(order.customer.id);
    const customer = await this.getCustomerForLogin(ctx);
    if (String(customer.id) !== customerId) throw new Error('ORDER_NOT_OWNED');
    const reference = `order:${order.id}`;
    return this.connection.withTransaction(ctx, async tx => {
      const walletRepo = this.connection.getRepository(tx, Rsvx7Wallet);
      const entryRepo = this.connection.getRepository(tx, Rsvx7WalletEntry);
      const existing = await entryRepo.findOne({ where: { reference } });
      if (existing) {
        if (existing.customerId !== customerId || existing.deltaCents !== -amountCents) {
          throw new Error('ORDER_DEBIT_MISMATCH');
        }
        return { reference, balanceCents: (await this.getBalance(tx, customerId)).balanceCents };
      }
      // Atomic conditional UPDATE: two concurrent purchases cannot overspend the wallet.
      const updated = await walletRepo.createQueryBuilder().update(Rsvx7Wallet)
        .set({ balanceCents: () => 'balanceCents - :amount' })
        .where('customerId = :cid', { cid: customerId })
        .andWhere('balanceCents >= :amount')
        .setParameters({ amount: amountCents }).execute();
      if (updated.affected !== 1) throw new Error('INSUFFICIENT_WALLET_BALANCE');
      const wallet = await walletRepo.findOneOrFail({ where: { customerId } });
      await entryRepo.save(entryRepo.create({
        customerId, deltaCents: -amountCents, balanceAfterCents: wallet.balanceCents,
        reference, memo: `Purchase order ${order.code}`,
      }));
      return { reference, balanceCents: wallet.balanceCents };
    });
  }
}
